﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace packetgo.Controls
{
    /// <summary>
    /// Interaction logic for TextBoxPasswordWithClear.xaml
    /// </summary>
    public partial class TextBoxPasswordWithClear : UserControl
    {

        public static DependencyProperty PlaceholderProperty = DependencyProperty.Register("PlaceholderPasswordClear", typeof(String), typeof(TextBoxPasswordWithClear));

        public string PlaceholderPasswordClear
        {
            get { return (string)GetValue(PlaceholderProperty); }
            set
            {
                SetValue(PlaceholderProperty, value);
            }
        }

        public static DependencyProperty PlaceholderHintProperty = DependencyProperty.Register("PlaceholderHintPasswordClear", typeof(String), typeof(TextBoxPasswordWithClear));

        public string PlaceholderHintPasswordClear
        {
            get { return (string)GetValue(PlaceholderHintProperty); }
            set
            {
                SetValue(PlaceholderHintProperty, value);
            }
        }

        public static DependencyProperty TextProperty = DependencyProperty.Register("TextValuePasswordClear", typeof(string), typeof(TextBoxPasswordWithClear));

        public string TextValuePasswordClear
        {
            get { return (string)GetValue(TextProperty); }
            set
            {
                SetValue(TextProperty, value);
            }
        }
       
        public TextBoxPasswordWithClear()
        {
            InitializeComponent();

            DataContext = this;
        }

        private void btnClear_Click(object sender, RoutedEventArgs e)
        {
            TextValuePasswordClear= "";
            txtValue.Focus();
        }
    }
}
