﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace packetgo.Controls
{
    /// <summary>
    /// Interaction logic for TextBoxPassword.xaml
    /// </summary>
    public partial class TextBoxPassword : UserControl
    {

        public static DependencyProperty PlaceholderPasswordProperty = DependencyProperty.Register("PlaceholderPassword", typeof(String), typeof(TextBoxPassword));

        public string PlaceholderPassword
        {
            get { return (string)GetValue(PlaceholderPasswordProperty); }
            set
            {
                SetValue(PlaceholderPasswordProperty, value);
            }
        }

        public static DependencyProperty PlaceholderHintPasswordProperty = DependencyProperty.Register("PlaceholderHintPassword", typeof(String), typeof(TextBoxPassword));

        public string PlaceholderHintPassword
        {
            get { return (string)GetValue(PlaceholderHintPasswordProperty); }
            set
            {
                SetValue(PlaceholderHintPasswordProperty, value);
            }
        }



        public string Text { get; set; }

        public TextBoxPassword()
        {
            InitializeComponent();

            DataContext = this;
        }
    }
}
