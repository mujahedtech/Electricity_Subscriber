﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace packetgo.Controls
{
    /// <summary>
    /// Interaction logic for TextBoxClearButton.xaml
    /// </summary>
    public partial class TextBoxClearButton : UserControl
    {


        public static DependencyProperty PlaceholderProperty = DependencyProperty.Register("Placeholder", typeof(String), typeof(TextBoxClearButton));

        public string Placeholder
        {
            get { return (string)GetValue(PlaceholderProperty); }
            set
            {
                SetValue(PlaceholderProperty, value);
            }
        }

        public static DependencyProperty PlaceholderHintProperty = DependencyProperty.Register("PlaceholderHint", typeof(String), typeof(TextBoxClearButton));

        public string PlaceholderHint
        {
            get { return (string)GetValue(PlaceholderHintProperty); }
            set
            {
                SetValue(PlaceholderHintProperty, value);
            }
        }

        public static DependencyProperty TextProperty = DependencyProperty.Register("TextValue", typeof(string), typeof(TextBoxClearButton));

        public string TextValue
        {
            get { return (string)GetValue(TextProperty); }
            set
            {
                SetValue(TextProperty, value);
            }
        }







        public TextBoxClearButton()
        {
            InitializeComponent();

            DataContext = this;
        }

        private void btnClear_Click(object sender, RoutedEventArgs e)
        {
            TextValue = "";
            txtValue.Focus();
        }
    }
}
