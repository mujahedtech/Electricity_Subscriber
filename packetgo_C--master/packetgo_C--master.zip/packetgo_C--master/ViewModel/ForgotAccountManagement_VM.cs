﻿using packetgo.MainPages;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Threading;

namespace packetgo.ViewModel
{
   public class ForgotAccountManagement_VM:ViewModelClass
    {
        public static event PropertyChangedEventHandler StaticPropertyChanged;

        private static void OnStaticPropertyChanged(string propertyName)
        {
            StaticPropertyChanged?.Invoke(null, new PropertyChangedEventArgs(propertyName));
        }


        public string PasswordSelected { get; set; } = "Mujahed";


        public bool PasswordValidtion_9_To_16 { get { return PasswordSelected.Length >= 9 && PasswordSelected.Length <= 16; } }

        public bool PasswordValidtion_English_letters_numbers_and_special_characters { get { return Regex.IsMatch(PasswordSelected, "^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[#?!@$%^&*-]).{8,}$"); } }


        #region Constrator




        private static bool _Findid = true;

        public static bool Findid
        {
            get { return _Findid; }
            set
            {
                _Findid = value;

                OnStaticPropertyChanged(nameof(Findid));
            }
        }


        private static bool _FindPassword;

        public static bool FindPassword
        {
            get { return _FindPassword; }
            set
            {
                _FindPassword = value;

                OnStaticPropertyChanged(nameof(FindPassword));
            }
        }

        public string UsernameSelected { get; set; } = "mujahed";

       

        #endregion


        #region Commands

        public ICommand GoBackCommand { get; set; }
        private void GoBackVoid(object parameter)
        {
            if (AppAccessGuide.Instance.MainGrid.CanGoBack) AppAccessGuide.Instance.MainGrid.GoBack();

        }



        public ICommand GoChangePasswordCommand { get; set; }
        private void GoChangePasswordVoid(object parameter)
        {
            AppAccessGuide.Instance.MainGrid.Navigate(new LoginPages.ChangePassword());

        }

        public ICommand GoLoginPageCommand { get; set; }
        private void GoLoginPageVoid(object parameter)
        {
            AppAccessGuide.Instance.MainGrid.Navigate(new LoginPages.LoginPage());

        }



        public ICommand RequestCodeByPhoneCommand { get; set; }
        private void RequestCodeByPhoneVoid(object parameter)
        {

            DispatcherTimerSetup();
        }
        #endregion


        #region Timer
        DispatcherTimer dispatcherTimer = new System.Windows.Threading.DispatcherTimer();
        public void DispatcherTimerSetup()
        {
            Nowtime = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, 0, 0, 10);
            dispatcherTimer = new System.Windows.Threading.DispatcherTimer();
            dispatcherTimer.Tick += DispatcherTimer_Tick;
            dispatcherTimer.Interval = new TimeSpan(0, 0, 1);
            dispatcherTimer.Start();
        }


        DateTime Nowtime = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, 0, 0, 10);
        private void DispatcherTimer_Tick(object? sender, EventArgs e)
        {
            if (Nowtime.Minute == 0 && Nowtime.Second == 0)
            {
                dispatcherTimer.Stop();
                DispatcherTimerSetup();
                return;
            }
            Nowtime = Nowtime.AddSeconds(-1);





            CountDown = Nowtime.ToString("mm:ss");
        }


        public string CountDown { get; set; }

        #endregion

        public ForgotAccountManagement_VM()
        {
            #region Commands
            GoBackCommand = new RelayCommand(GoBackVoid);
            RequestCodeByPhoneCommand = new RelayCommand(RequestCodeByPhoneVoid);

            GoChangePasswordCommand=new  RelayCommand(GoChangePasswordVoid);
            GoLoginPageCommand=new  RelayCommand(GoLoginPageVoid);


            #endregion


        }
    }
}
