﻿using packetgo.MainPages;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Threading;

namespace packetgo.ViewModel
{
    public class QR_VerificationViewModel : ViewModel.ViewModelClass
    {


        public ICommand ForgetSimpleCodeCommand { get; set; }
        private void ForgetSimpleCodeVoid(object parameter)
        {

            AppAccessGuide.Instance.MainGrid.Navigate(new LoginPages.ForgotSimpleCode());

        }



        DispatcherTimer dispatcherTimer = new System.Windows.Threading.DispatcherTimer();
        public void DispatcherTimerSetup()
        {
            Nowtime = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, 0, 0, 10);
            dispatcherTimer = new System.Windows.Threading.DispatcherTimer();
            dispatcherTimer.Tick += DispatcherTimer_Tick;
            dispatcherTimer.Interval = new TimeSpan(0, 0, 1);
            dispatcherTimer.Start();
        }


        DateTime Nowtime = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, 0, 0, 10);
        private void DispatcherTimer_Tick(object? sender, EventArgs e)
        {
            if (Nowtime.Minute == 0 && Nowtime.Second == 0)
            {
                dispatcherTimer.Stop();
                DispatcherTimerSetup();
                return;
            }
            Nowtime = Nowtime.AddSeconds(-1);





            CountDown = Nowtime.ToString("mm:ss");
        }


        public string CountDown { get; set; }


        public ICommand CloseAppCommand { get; set; }
        private void CloseAppVoid(object parameter)
        {
            Application.Current.Shutdown();

        }

        public ICommand MinimizeAppCommand { get; set; }
        private void MinimizeAppVoid(object parameter)
        {
            AppAccessGuide.Instance.WindowState = WindowState.Minimized;

        }


        public ICommand GoBackCommand { get; set; }
        private void GoBackVoid(object parameter)
        {
            if (AppAccessGuide.Instance.MainGrid.CanGoBack) AppAccessGuide.Instance.MainGrid.GoBack();

        }



        public QR_VerificationViewModel()
        {
            DispatcherTimerSetup();

            ForgetSimpleCodeCommand = new RelayCommand(ForgetSimpleCodeVoid);
            CloseAppCommand = new RelayCommand(CloseAppVoid);
            MinimizeAppCommand = new RelayCommand(MinimizeAppVoid);

            GoBackCommand = new RelayCommand(GoBackVoid);
        }

    }
}
