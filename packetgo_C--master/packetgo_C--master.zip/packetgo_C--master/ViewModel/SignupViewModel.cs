﻿using packetgo.MainPages;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Reflection.Metadata;
using System.Runtime.Intrinsics.X86;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;

namespace packetgo.ViewModel
{

    public class Terms_Of_ServiceModel
    {
        public int Id { get; set; }
        public string Title { get; set; } = "";
        public string Details { get; set; } = "";

        public bool DetailsVisible { get; set; }


    }

    public class Usage_AgreementModel
    {
        public int Id { get; set; }
        public string Title { get; set; } = "";
        public string Details { get; set; } = "";

        public bool DetailsVisible { get; set; }


    }


    public class AccountInfoModel
    {
        public int Id { get; set; }
        public string Username { get; set; } = "";
        public string Email { get; set; } = "";

        public string Password { get; set; } = "";

        public string Phone { get; set; } = "";


    }





    public class SignupViewModel : ViewModel.ViewModelClass
    {
        #region Lists
        private ObservableCollection<Terms_Of_ServiceModel> _Terms_Of_ServiceList = new ObservableCollection<Terms_Of_ServiceModel>();
        public ObservableCollection<Terms_Of_ServiceModel> Terms_Of_ServiceList
        {
            get
            {

                return _Terms_Of_ServiceList;

            }
            set
            {
                _Terms_Of_ServiceList = value;
                OnPropertyChanged(nameof(Terms_Of_ServiceList));
            }

        }



        private ObservableCollection<Usage_AgreementModel> _Usage_AgreementList = new ObservableCollection<Usage_AgreementModel>();
        public ObservableCollection<Usage_AgreementModel> Usage_AgreementList
        {
            get
            {

                return _Usage_AgreementList;

            }
            set
            {
                _Usage_AgreementList = value;
                OnPropertyChanged(nameof(Usage_AgreementList));
            }

        }


        private ObservableCollection<AccountInfoModel> _AccountInfoList = new ObservableCollection<AccountInfoModel>();
        public ObservableCollection<AccountInfoModel> AccountInfoList
        {
            get
            {

                return _AccountInfoList;

            }
            set
            {
                _AccountInfoList = value;
                OnPropertyChanged(nameof(AccountInfoList));
            }

        }

        #endregion


        #region Commands
        public ICommand CloseAppCommand { get; set; }
        private void CloseAppVoid(object parameter)
        {
            Application.Current.Shutdown();

        }

        public ICommand MinimizeAppCommand { get; set; }
        private void MinimizeAppVoid(object parameter)
        {
            AppAccessGuide.Instance.WindowState = WindowState.Minimized;

        }


        public ICommand GoBackCommand { get; set; }
        private void GoBackVoid(object parameter)
        {
            if (AppAccessGuide.Instance.MainGrid.CanGoBack) AppAccessGuide.Instance.MainGrid.GoBack();

        }

        public ICommand AgreeToAllTermsAndConditionsCommand { get; set; }
        private void AgreeToAllTermsAndConditionsVoid(object parameter)
        {
            AgreeToAllTermsAndConditions = Required_agreement_to_Terms_of_Service = Required_of_Usage_Agreement = true;



        }

        public ICommand GoTerms_Of_ServiceCommand { get; set; }
        private void GoTerms_Of_ServiceVoid(object parameter)
        {
            AppAccessGuide.Instance.MainGrid.Navigate(new SignupPages.Terms_Of_Service());


        }

        public ICommand GoUsage_AgreementCommand { get; set; }
        private void GoUsage_AgreementVoid(object parameter)
        {
            AppAccessGuide.Instance.MainGrid.Navigate(new SignupPages.Usage_Agreement());


        }


        public ICommand AcceptTerms_Of_ServiceCommand { get; set; }
        private void AcceptTerms_Of_ServiceVoid(object parameter)
        {
            if (AppAccessGuide.Instance.MainGrid.CanGoBack) AppAccessGuide.Instance.MainGrid.GoBack();



            Required_agreement_to_Terms_of_Service = true;

            if (Required_agreement_to_Terms_of_Service && Required_of_Usage_Agreement == true) AgreeToAllTermsAndConditions = true;

        }

        public ICommand AcceptUsage_AgreementCommand { get; set; }
        private void AcceptUsage_AgreementVoid(object parameter)
        {
            if (AppAccessGuide.Instance.MainGrid.CanGoBack) AppAccessGuide.Instance.MainGrid.GoBack();

            Required_of_Usage_Agreement = true;

            if (Required_agreement_to_Terms_of_Service && Required_of_Usage_Agreement == true) AgreeToAllTermsAndConditions = true;

        }




        public ICommand OpenAccountInformationCommand { get; set; }
        private void OpenAccountInformationVoid(object parameter)
        {
            if (Required_agreement_to_Terms_of_Service && Required_of_Usage_Agreement && AgreeToAllTermsAndConditions)
                AppAccessGuide.Instance.MainGrid.Navigate(new SignupPages.AccountInformation());

        }



        public ICommand OpenEmail_verificationCommand { get; set; }
        private void OpenEmail_verificationVoid(object parameter)
        {

            AppAccessGuide.Instance.MainGrid.Navigate(new SignupPages.Email_verification());

            SentEmailverification = EmailSelected;


            OnStaticPropertyChanged(nameof(SentEmailverification));

        }


        public ICommand OpenJoin_The_MembershipCommand { get; set; }
        private void OpenJoin_The_MembershipVoid(object parameter)
        {

            AppAccessGuide.Instance.MainGrid.Navigate(new SignupPages.Join_The_Membership());

        }


        public ICommand OpenEnterSimplePasswordCommand { get; set; }
        private void OpenEnterSimplePasswordVoid(object parameter)
        {

            AppAccessGuide.Instance.MainGrid.Navigate(new SignupPages.EnterSimplePassword());

        }


        #endregion


        public SignupViewModel()
        {

            #region Commands
            CloseAppCommand = new RelayCommand(CloseAppVoid);
            MinimizeAppCommand = new RelayCommand(MinimizeAppVoid);

            GoBackCommand = new RelayCommand(GoBackVoid);
            AgreeToAllTermsAndConditionsCommand = new RelayCommand(AgreeToAllTermsAndConditionsVoid);

            GoTerms_Of_ServiceCommand = new RelayCommand(GoTerms_Of_ServiceVoid);
            GoUsage_AgreementCommand = new RelayCommand(GoUsage_AgreementVoid);




            AcceptTerms_Of_ServiceCommand = new RelayCommand(AcceptTerms_Of_ServiceVoid);
            AcceptUsage_AgreementCommand = new RelayCommand(AcceptUsage_AgreementVoid);



            OpenAccountInformationCommand = new RelayCommand(OpenAccountInformationVoid);
            OpenEmail_verificationCommand = new RelayCommand(OpenEmail_verificationVoid);

            OpenJoin_The_MembershipCommand = new RelayCommand(OpenJoin_The_MembershipVoid);

            OpenEnterSimplePasswordCommand = new RelayCommand(OpenEnterSimplePasswordVoid);






            #endregion


            #region Lists



            #region Terms Of service

            Terms_Of_ServiceList.Add(new Terms_Of_ServiceModel
            {
                Title = "개인정보의 수집•이용 목적",
                Details = "- 회원 관리 및 맞춤 서비스 제공",
                Id = Terms_Of_ServiceList.Count + 1,
                DetailsVisible = true,
            });


            Terms_Of_ServiceList.Add(new Terms_Of_ServiceModel
            {
                Title = "수집하는 개인정보의 항목",
                Details = "- 필수 항목 : 이름, 아이디(이메일), 비밀번호, (연락처)휴대폰 번호, 간편 비밀번호",
                Id = Terms_Of_ServiceList.Count + 1,
                DetailsVisible = true,
            });



            Terms_Of_ServiceList.Add(new Terms_Of_ServiceModel
            {
                Title = "개인정보의 보유 기간",
                Details = "- 서비스 해지 등 자격 상실 전 까지, 관계법력에 따른 보유기간이 별도로 있을 경우 해당 기간까지",
                Id = Terms_Of_ServiceList.Count + 1,
                DetailsVisible = true,
            });

            Terms_Of_ServiceList.Add(new Terms_Of_ServiceModel
            {
                Title = "이용자는 개인정보 수집 및 이용 동의를 거부할 권리가 있습니다. ",
                Details = "",
                Id = Terms_Of_ServiceList.Count + 1,
                DetailsVisible = false,
            });


            Terms_Of_ServiceList.Add(new Terms_Of_ServiceModel
            {
                Title = "단, 위 항목에 대한 동의 거부 시 서비스 가입이 불가능함을 알려드립니다.",
                Details = "",
                Id = Terms_Of_ServiceList.Count + 1,
                DetailsVisible = true,
            });

            Terms_Of_ServiceList.Add(new Terms_Of_ServiceModel
            {
                Title = "상세 내용은 개인정보처리방침을 참고해주시기 바랍니다.",
                Details = "",
                Id = Terms_Of_ServiceList.Count + 1,
                DetailsVisible = true,
            });




            Terms_Of_ServiceList.Add(new Terms_Of_ServiceModel
            {
                Title = "개인정보의 수집•이용 목적",
                Details = "- 회원 관리 및 맞춤 서비스 제공",
                Id = Terms_Of_ServiceList.Count + 1,
                DetailsVisible = true,
            });


            Terms_Of_ServiceList.Add(new Terms_Of_ServiceModel
            {
                Title = "수집하는 개인정보의 항목",
                Details = "- 필수 항목 : 이름, 아이디(이메일), 비밀번호, (연락처)휴대폰 번호, 간편 비밀번호",
                Id = Terms_Of_ServiceList.Count + 1,
                DetailsVisible = true,
            });


            Terms_Of_ServiceList.Add(new Terms_Of_ServiceModel
            {
                Title = "개인정보의 보유 기간",
                Details = "- 서비스 해지 등 자격 상실 전 까지, 관계법력에 따른 보유기간이 별도로 있을 경우 해당 기간까지",
                Id = Terms_Of_ServiceList.Count + 1,
                DetailsVisible = true,
            });

            Terms_Of_ServiceList.Add(new Terms_Of_ServiceModel
            {
                Title = "이용자는 개인정보 수집 및 이용 동의를 거부할 권리가 있습니다. ",
                Details = "",
                Id = Terms_Of_ServiceList.Count + 1,
                DetailsVisible = false,
            });

            Terms_Of_ServiceList.Add(new Terms_Of_ServiceModel
            {
                Title = "단, 위 항목에 대한 동의 거부 시 서비스 가입이 불가능함을 알려드립니다.",
                Details = "",
                Id = Terms_Of_ServiceList.Count + 1,
                DetailsVisible = true,
            });

            Terms_Of_ServiceList.Add(new Terms_Of_ServiceModel
            {
                Title = "상세 내용은 개인정보처리방침을 참고해주시기 바랍니다.",
                Details = "",
                Id = Terms_Of_ServiceList.Count + 1,
                DetailsVisible = false,
            });

            #endregion

            #region Usage Agreement



            Usage_AgreementList.Add(new Usage_AgreementModel
            {
                Title = "개인정보의 수집•이용 목적",
                Details = "- 회원 관리 및 맞춤 서비스 제공",
                Id = Terms_Of_ServiceList.Count + 1,
                DetailsVisible = true,
            });

            Usage_AgreementList.Add(new Usage_AgreementModel
            {
                Title = "수집하는 개인정보의 항목",
                Details = "- 필수 항목 : 이름, 아이디(이메일), 비밀번호, (연락처)휴대폰 번호, 간편 비밀번호",
                Id = Terms_Of_ServiceList.Count + 1,
                DetailsVisible = true,
            });

            Usage_AgreementList.Add(new Usage_AgreementModel
            {
                Title = "개인정보의 보유 기간",
                Details = "- 서비스 해지 등 자격 상실 전 까지, 관계법력에 따른 보유기간이 별도로 있을 경우 해당 기간까지",
                Id = Terms_Of_ServiceList.Count + 1,
                DetailsVisible = true,
            });

            Usage_AgreementList.Add(new Usage_AgreementModel
            {
                Title = "이용자는 개인정보 수집 및 이용 동의를 거부할 권리가 있습니다. ",
                Details = "",
                Id = Terms_Of_ServiceList.Count + 1,
                DetailsVisible = false,
            });
            Usage_AgreementList.Add(new Usage_AgreementModel
            {
                Title = "단, 위 항목에 대한 동의 거부 시 서비스 가입이 불가능함을 알려드립니다.",
                Details = "",
                Id = Terms_Of_ServiceList.Count + 1,
                DetailsVisible = true,
            });

            Usage_AgreementList.Add(new Usage_AgreementModel
            {
                Title = "상세 내용은 개인정보처리방침을 참고해주시기 바랍니다.",
                Details = "",
                Id = Terms_Of_ServiceList.Count + 1,
                DetailsVisible = true,
            });
            Usage_AgreementList.Add(new Usage_AgreementModel
            {
                Title = "개인정보의 수집•이용 목적",
                Details = "- 회원 관리 및 맞춤 서비스 제공",
                Id = Terms_Of_ServiceList.Count + 1,
                DetailsVisible = true,
            });

            Usage_AgreementList.Add(new Usage_AgreementModel
            {
                Title = "수집하는 개인정보의 항목",
                Details = "- 필수 항목 : 이름, 아이디(이메일), 비밀번호, (연락처)휴대폰 번호, 간편 비밀번호",
                Id = Terms_Of_ServiceList.Count + 1,
                DetailsVisible = true,
            });

            Usage_AgreementList.Add(new Usage_AgreementModel
            {
                Title = "개인정보의 보유 기간",
                Details = "- 서비스 해지 등 자격 상실 전 까지, 관계법력에 따른 보유기간이 별도로 있을 경우 해당 기간까지",
                Id = Terms_Of_ServiceList.Count + 1,
                DetailsVisible = true,
            });

            Usage_AgreementList.Add(new Usage_AgreementModel
            {
                Title = "이용자는 개인정보 수집 및 이용 동의를 거부할 권리가 있습니다. ",
                Details = "",
                Id = Terms_Of_ServiceList.Count + 1,
                DetailsVisible = false,
            }); Usage_AgreementList.Add(new Usage_AgreementModel
            {
                Title = "단, 위 항목에 대한 동의 거부 시 서비스 가입이 불가능함을 알려드립니다.",
                Details = "",
                Id = Terms_Of_ServiceList.Count + 1,
                DetailsVisible = true,
            });

            Usage_AgreementList.Add(new Usage_AgreementModel
            {
                Title = "상세 내용은 개인정보처리방침을 참고해주시기 바랍니다.",
                Details = "",
                Id = Terms_Of_ServiceList.Count + 1,
                DetailsVisible = false,
            });

            #endregion


            #region AccountInfoList 



            AccountInfoList.Add(new AccountInfoModel
            {
                Username = "Mujahed",
                Email = "Mujahed.jaraydeh@outlook.com",
                Password = "Password",
                Phone = "+962790931724",
                Id = AccountInfoList.Count + 1,

            });

            AccountInfoList.Add(new AccountInfoModel
            {
                Username = "Ahmad",
                Email = "Ahmad.jaraydeh@outlook.com",
                Password = "Password",
                Phone = "+962790931725",
                Id = AccountInfoList.Count + 1,

            });

            AccountInfoList.Add(new AccountInfoModel
            {
                Username = "Hyun",
                Email = "Hyun@github.com",
                Password = "Password",
                Phone = "+962790931725",
                Id = AccountInfoList.Count + 1,

            });



            #endregion


            #endregion

        }


        #region Constractor





        private static bool _Required_of_Usage_Agreement;

        public static bool Required_of_Usage_Agreement
        {
            get { return _Required_of_Usage_Agreement; }
            set
            {
                _Required_of_Usage_Agreement = value;

                OnStaticPropertyChanged(nameof(Required_of_Usage_Agreement));
            }
        }



        private static bool _Required_agreement_to_Terms_of_Service;

        public static bool Required_agreement_to_Terms_of_Service
        {
            get { return _Required_agreement_to_Terms_of_Service; }
            set
            {
                _Required_agreement_to_Terms_of_Service = value;

                OnStaticPropertyChanged(nameof(Required_agreement_to_Terms_of_Service));
            }
        }


        private static bool _AgreeToAllTermsAndConditions;

        public static bool AgreeToAllTermsAndConditions
        {
            get { return _AgreeToAllTermsAndConditions; }
            set
            {
                _AgreeToAllTermsAndConditions = value;

                OnStaticPropertyChanged(nameof(AgreeToAllTermsAndConditions));
            }
        }






        public string UsernameSelected { get; set; } = "mujahed";

        public bool UserIsAvailable { get { return AccountInfoList.Where(i => i.Username.ToLower() == UsernameSelected.ToLower()).Count() == 0; } }





        public string EmailSelected { get; set; } = "Mujahed.jaraydhe@outlook.com";


        public bool EmailIsAvailable { get { return AccountInfoList.Where(i => i.Email.ToLower() == EmailSelected.ToLower()).Count() == 0; } }



        private static string _SentEmailverification;

        public static string SentEmailverification
        {
            get { return _SentEmailverification; }
            set
            {
                _SentEmailverification = value;

                OnStaticPropertyChanged(nameof(SentEmailverification));
            }
        }




        public string PasswordSelected { get; set; } = "Mujahed";


        public bool PasswordValidtion_9_To_16 { get { return PasswordSelected.Length >= 9 && PasswordSelected.Length <= 16; } }

        public bool PasswordValidtion_English_letters_numbers_and_special_characters { get { return Regex.IsMatch(PasswordSelected, "^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[#?!@$%^&*-]).{8,}$"); } }


        int SimpleCoseSaved = 123456;

        private string simplecode;
        public string SimpleCode
        {
            get
            {
                return simplecode;
            }
            set
            {
                simplecode = value;
                OnPropertyChanged(nameof(SimpleCode));

                if (simplecode != null) if (int.Parse(simplecode) == SimpleCoseSaved)
                    {
                        AppAccessGuide.Instance.MainGrid.Navigate(new LoginPages.LoginPage());



                    }
                    else
                    {

                    }

            }

        }



        int EmailVertificationCodeSaved = 123456;

        private string _EmailVertificationCode;
        public string EmailVertificationCode
        {
            get
            {
                return _EmailVertificationCode;
            }
            set
            {
                _EmailVertificationCode = value;
                OnPropertyChanged(nameof(EmailVertificationCode));

                if (_EmailVertificationCode != null) if (int.Parse(_EmailVertificationCode) == EmailVertificationCodeSaved)

                    {
                        Color = "#754DF8";
                        EmailVertificationFillSuccess = true;


                    }
                    else
                    {
                        Color = "#25232E";
                        EmailVertificationFillSuccess = false;
                    }

            }

        }

        public string Color { set; get; } = "#25232E";


        public bool EmailVertificationFillSuccess { get; set; }





        #endregion

        public static event PropertyChangedEventHandler StaticPropertyChanged;

        private static void OnStaticPropertyChanged(string propertyName)
        {
            StaticPropertyChanged?.Invoke(null, new PropertyChangedEventArgs(propertyName));
        }
    }
}
