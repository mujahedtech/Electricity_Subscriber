﻿
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Threading;
using packetgo.MainPages;

namespace packetgo.ViewModel
{
    public class LanguageTable
    {
        public string Name { get; set; } = "";

        public int Id { get; set; }

        public bool Active { get; set; }

    }

    public class LoginUseSocialNetworkTable
    {
        public string Name { get; set; } = "";

        public int Id { get; set; }

        public string Image { get; set; } = "";

    }


    public class LanguagePageVM: ViewModel.ViewModelClass
    {

        #region Lists
        private ObservableCollection<LoginUseSocialNetworkTable> socialnetworklist = new ObservableCollection<LoginUseSocialNetworkTable>();
        public ObservableCollection<LoginUseSocialNetworkTable> SocialNetworkList
        {
            get
            {

                return socialnetworklist;

            }
            set
            {
                socialnetworklist = value;
                OnPropertyChanged(nameof(SocialNetworkList));
            }

        }


        private ObservableCollection<LanguageTable> langlist = new ObservableCollection<LanguageTable>();
        public ObservableCollection<LanguageTable> LanguagesList
        {
            get
            {

                return langlist;

            }
            set
            {
                langlist = value;
                OnPropertyChanged(nameof(LanguagesList));
            }

        }

        #endregion

        #region Command
        public ICommand ChangeLangaugeCommand { get; set; }
        private void ChangeLangaugeVoid(object parameter)
        {

            AppAccessGuide.Instance.Resources.MergedDictionaries.Clear();

            ResourceDictionary SelectedLanguage = new ResourceDictionary();
          

            var langauge = (LanguageTable)parameter;

            switch (langauge.Name)
            {
                case "한국어(Korean)":

                    
                    SelectedLanguage.Source = new Uri("/packetgo;component/Languages/KoLanguage.xaml", UriKind.RelativeOrAbsolute);
                    AppAccessGuide.Instance.Resources.MergedDictionaries.Add(SelectedLanguage);

                   

                   
                    break;
                case "영어(english)":

                    SelectedLanguage.Source = new Uri("/packetgo;component/Languages/EnLanguage.xaml", UriKind.RelativeOrAbsolute);
                    AppAccessGuide.Instance.Resources.MergedDictionaries.Add(SelectedLanguage);
                    break;
                case "일본어(Japanese)":

                    SelectedLanguage.Source = new Uri("/packetgo;component/Languages/JapanLanguage.xaml", UriKind.RelativeOrAbsolute);
                    AppAccessGuide.Instance.Resources.MergedDictionaries.Add(SelectedLanguage);
                    break;
                case "중국어(Chinese)":

                    SelectedLanguage.Source = new Uri("/packetgo;component/Languages/ChineseLanguage.xaml", UriKind.RelativeOrAbsolute);
                    AppAccessGuide.Instance.Resources.MergedDictionaries.Add(SelectedLanguage);
                    break;

            }


           

        }


        public ICommand OpenPermissionPageCommand { get; set; }
        private void OpenPermissionPageVoid(object parameter)
        {
            AppAccessGuide.Instance.GridSelectLanguage.Children.Clear();
             AppAccessGuide.Instance.MainGrid.Navigate(new LoginPages.AppAccessPermissionInformation());

        }

        public ICommand OpenLoginPageCommand { get; set; }
        private void OpenLoginPageVoid(object parameter)
        {

            AppAccessGuide.Instance.MainGrid.Navigate(new LoginPages.LoginPage());

        }



        static packetgo.MiniWindows.MessagePopup MessagePopup;
        public ICommand OpenLogPopupCommand { get; set; }
        private void OpenLogPopupVoid(object parameter)
        {



            MessagePopup = new packetgo.MiniWindows.MessagePopup() ;

            MessagePopup.ShowDialog();

        }


        public ICommand OpenSecureAccessCommand { get; set; }
        private void OpenSecureAccessVoid(object parameter)
        {


            MessagePopup.Close();

           

            AppAccessGuide.Instance.MainGrid.Navigate(new LoginPages.SecureAccess());



        }

        public ICommand ForgetSimpleCodeCommand { get; set; }
        private void ForgetSimpleCodeVoid(object parameter)
        {

            AppAccessGuide.Instance.MainGrid.Navigate(new LoginPages.ForgotSimpleCode());

        }


        public ICommand CloseAppCommand { get; set; }
        private void CloseAppVoid(object parameter)
        {
            Application.Current.Shutdown();

        }

        public ICommand MinimizeAppCommand { get; set; }
        private void MinimizeAppVoid(object parameter)
        {
            AppAccessGuide.Instance.WindowState = WindowState.Minimized;

        }


        public ICommand GoBackCommand { get; set; }
        private void GoBackVoid(object parameter)
        {
          if(AppAccessGuide.Instance.MainGrid.CanGoBack)AppAccessGuide.Instance.MainGrid.GoBack();

        }

        public ICommand GoTermsAndConditionsCommand { get; set; }
        private void GoTermsAndConditionsVoid(object parameter)
        {
            AppAccessGuide.Instance.MainGrid.Navigate(new SignupPages.Agree_To_Terms_and_Conditions());

        }
        public ICommand ClickMeCommand { get; set; }
        private void ClickMeVoid(object parameter)
        {
           

        }


        public ICommand GoForgotidCommand { get; set; }
        private void GoForgotidVoid(object parameter)
        {
            ViewModel.ForgotAccountManagement_VM.Findid = true;
            AppAccessGuide.Instance.MainGrid.Navigate(new LoginPages.ForgotAccountManagement());

        }

        public ICommand GoForgotpasswordCommand { get; set; }
        private void GoForgotpasswordVoid(object parameter)
        {
            ViewModel.ForgotAccountManagement_VM.FindPassword = true;
            AppAccessGuide.Instance.MainGrid.Navigate(new LoginPages.ForgotAccountManagement());

        }

        #endregion

        public LanguagePageVM()
        {
            #region Commands


            ChangeLangaugeCommand = new RelayCommand(ChangeLangaugeVoid);
            OpenPermissionPageCommand = new RelayCommand(OpenPermissionPageVoid);
            OpenLoginPageCommand = new RelayCommand(OpenLoginPageVoid);
            OpenLogPopupCommand = new RelayCommand(OpenLogPopupVoid);
            OpenSecureAccessCommand = new RelayCommand(OpenSecureAccessVoid);

            ForgetSimpleCodeCommand = new RelayCommand(ForgetSimpleCodeVoid);

            CloseAppCommand = new RelayCommand(CloseAppVoid);
            MinimizeAppCommand = new RelayCommand(MinimizeAppVoid);

            GoBackCommand = new RelayCommand(GoBackVoid);

            GoTermsAndConditionsCommand = new RelayCommand(GoTermsAndConditionsVoid);


            ClickMeCommand = new RelayCommand(ClickMeVoid);

            GoForgotidCommand= new RelayCommand(GoForgotidVoid);

            GoForgotpasswordCommand = new RelayCommand(GoForgotpasswordVoid);




            #endregion

            #region Lists

            LanguagesList.Add(new LanguageTable { Id = 1, Name = "한국어(Korean)" ,Active=false});
            LanguagesList.Add(new LanguageTable { Id = 2, Name = "영어(english)", Active = true });
            LanguagesList.Add(new LanguageTable { Id = 3, Name = "일본어(Japanese)", Active = false });
            LanguagesList.Add(new LanguageTable { Id = 4, Name = "중국어(Chinese)", Active = false });
            LanguagesList.Add(new LanguageTable { Id = 5, Name = "중국어(中文)", Active = false });
            LanguagesList.Add(new LanguageTable { Id = 6, Name = "중국어(中文)" , Active = false });
            LanguagesList.Add(new LanguageTable { Id = 7, Name = "중국어(中文)" , Active = false });
            LanguagesList.Add(new LanguageTable { Id = 8, Name = "중국어(中文)" , Active = false });




            SocialNetworkList.Add(new LoginUseSocialNetworkTable { Id = 1, Name = "Pass Network", Image = "Images/PassIcon.png" });
            SocialNetworkList.Add(new LoginUseSocialNetworkTable { Id = 2, Name = "network2", Image = "Images/network2.png" });
            SocialNetworkList.Add(new LoginUseSocialNetworkTable { Id = 3, Name = "network3", Image = "Images/network3.png" });
            SocialNetworkList.Add(new LoginUseSocialNetworkTable { Id = 4, Name = "Apple Network", Image = "Images/applenetwork.png" });
            SocialNetworkList.Add(new LoginUseSocialNetworkTable { Id = 5, Name = "Facebook Network", Image = "Images/facebooknetwork.png" });
            SocialNetworkList.Add(new LoginUseSocialNetworkTable { Id = 6, Name = "Google Network", Image = "Images/googlenetwork.png" });
            SocialNetworkList.Add(new LoginUseSocialNetworkTable { Id = 7, Name = "New Network", Image = "Images/newNetwork.png" });
         



            #endregion

        }





        public static string EmailUser { get; set; }



        





        int SimpleCoseSaved = 123456;

        private string simplecode;
        public string SimpleCode
        {
            get
            {
                return simplecode;
            }
            set
            {
                simplecode = value;
                OnPropertyChanged(nameof(SimpleCode));

                if (simplecode != null) if (int.Parse(simplecode) == SimpleCoseSaved)
                    {
                        AppAccessGuide.Instance.MainGrid.Navigate(new LoginPages.QR_Verification());
                       
                    } 

            }

        }




    




    }
}
