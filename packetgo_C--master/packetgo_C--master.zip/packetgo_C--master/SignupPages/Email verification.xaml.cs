﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace packetgo.SignupPages
{
    /// <summary>
    /// Interaction logic for Email_verification.xaml
    /// </summary>
    public partial class Email_verification : UserControl
    {
        public Email_verification()
        {
            InitializeComponent();
            Loaded += Email_verification_Loaded;

           
        }

        private void Email_verification_Loaded(object sender, RoutedEventArgs e)
        {
            txtSecureAccess.Focus();
        }

        private void txtSecureAccess_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            Regex regex = new Regex("[^0-9]+");
            e.Handled = regex.IsMatch(e.Text);
        }
    }
}
