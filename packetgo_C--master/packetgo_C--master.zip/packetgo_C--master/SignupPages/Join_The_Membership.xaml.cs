﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace packetgo.SignupPages
{
    /// <summary>
    /// Interaction logic for Join_The_Membership.xaml
    /// </summary>
    public partial class Join_The_Membership : UserControl
    {
        public Join_The_Membership()
        {
            InitializeComponent();
        }
    }
}
